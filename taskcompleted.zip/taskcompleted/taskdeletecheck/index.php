<?php
// session_start();
// require_once('conn.php');
// session_start();
// $page=$_GET['page'];
// $_SESSION['page']=$page;
require_once('conn.php');
 ?>
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" id="font-awesome-style-css" href="https://www.phpflow.com/code/css/bootstrap3.min.css" type="text/css" media="all">
	<script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.8.2.min.js"></script>

	<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script> -->
	<title>Home</title>
	<style type="text/css">
		*
		{
			margin: 0;
			padding: 0;
		}
		.head
		{
			height: 50px;
			background-color: #3492eb;
		}
		.pd_div
		{
		    background-color: #e7e7e7;
		    height: 50px;
		    display: flex;
		    justify-content: space-between;
		    align-content: center;
		    align-items: center;	   
		}
		.add_user
		{
			 text-decoration: none;
			 background-color: #14c71a;
			 padding: 8px 20px;
			 margin: 0px 20px;
			 color: white;
			 border-radius: 20px;
		}
		.add_user:hover
		{
			 text-decoration: none;
			  color: white;
		}
		.heading
		{
			margin-left: 20px;
			font-size: 24px;
			font-weight: bold;
		}
		.filter_search
		{
            height: 80px;
            /*background-color: #abdc;*/
            display: flex;
            align-items: center;
            float: right;
            margin-right: 20px;


            /*justify-content: space-between;*/

		}
		.search
		{
			outline: none;
			padding: 5px 8px;
		}
		.search_btn
		{
			padding: 5px 8px;
			cursor: pointer;
		}
		.search_country,.search_state
		{
				padding: 7px 8px;
				cursor: pointer;
				width: 100px;
				outline: none;
		}
		.clear
		{
			clear: both;
			display: flex;
			justify-content: center;
		}
		#list 
		{
		  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
		  border-collapse: collapse;
		  width: 100%;
        }

        #list td, #list th 
        {
		  border: 1px solid #ddd;
		  padding: 8px;
		  text-align: center;
        }	

        #list th 
        {
          text-align: center;
        }

        #list tr:nth-child(even)
        {
        	background-color: #f2f2f2;
        }

		#list tr:hover 
		{
			background-color: #ddd;
			cursor: pointer;
		}

		#list th 
		{
		  padding-top: 12px;
		  padding-bottom: 12px;
		  text-align: center;
		  background-color: #4CAF50;
		  color: white;
		}
		.pagelist
		{
             text-decoration: none;
             background-color: #182c4d;
             color: white;
             padding: 3px 10px;
		}
		#bulk_delete
		{
			margin-bottom: 10px;;
			float: right;
			margin-right: 10px;
			outline: none;
		}
	
	</style>
</head>
<body>
	<div class="head">
		
	</div>

	<div class="pd_div">
		<p class="heading">Personal Details</p>
		<a class="add_user" href="personal_detail.php">Add User</a>
	</div>

	<div class="filter_search">
		<div class="search_right">
			<select class="search_country" id="search_input_country" name="" >
				<option>Select</option>
				 <?php
			     $sql="SELECT*FROM country";
			     $run=mysqli_query($conn,$sql);
			     while($row=$run->fetch_assoc()) 
			     {
			         // echo $row['country'];
			     
			     
				?>
			       <option value="<?php echo $row['c_id'] ?>"><?php echo $row['country_name'];}?></option>
			</select>
				<select  name="state" id="state" class="search_state">
			       <option value="select">Select</option>		   
				</select>
			<input type="text" class="search" id="search_input" name="" placeholder="Search">
			<button class="search_btn" id="search_btn" name="search">Search</button>
	     </div>
	</div>

<div class="clear" >
	 
</div> 

<div>
	<button id="bulk_delete" class="btn btn-danger">Delete All</button>

</div>

<div id="target-content" >loading...</div>
	
<script type="text/javascript">

$(document).ready(function() {

$("#target-content").load("pagination.php?page=1");
     $(document).on('click','#search_btn',function(e){

     	e.preventDefault();
		$("#target-content").html('loading...');
		$("#pagination li").removeClass('active');
		$(this).addClass('active');
        var pageNum = 1;
        var searchdata=$('#search_input').val();
        var countrydata=$('#search_input_country').val();
        var statedata=$('#state').val();
        $("#target-content").load("pagination.php?page=" + pageNum + "&searchdata=" + searchdata + "&countrydata=" + countrydata  + "&statedata=" + statedata);     	
     });
       $(document).on('click','#pagination li',function(e){
     	e.preventDefault();
		$("#target-content").html('loading...');
		$("#pagination li").removeClass('active');
		$(this).addClass('active');
        var pageNum = this.id;
        var searchdata=$('#search_input').val();
        var countrydata=$('#search_input_country').val();
        var statedata=$('#state').val();
        $("#target-content").load("pagination.php?page=" + pageNum + "&searchdata=" + searchdata + "&countrydata=" + countrydata + "&statedata=" + statedata);  	
     });

        $(document).on('change','#search_input_country',function(e){
     	e.preventDefault();
		$("#target-content").html('loading...');
		$("#pagination li").removeClass('active');
		$(this).addClass('active');
        var pageNum = 1;
        var searchdata=$('#search_input').val();
        var countrydata=$('#search_input_country').val();
        var statedata=$('#state').val();
        $("#target-content").load("pagination.php?page=" + pageNum + "&searchdata=" + searchdata + "&countrydata=" + countrydata + "&statedata=" + statedata);  
        func(); //function
     });
       
  	  //// delete single data

     $(document).on('click','.delete_btn',function(e){
        var id = $(this).attr("id");
        // alert(id)
        if(confirm('Are you sure to delete this record ?')) {
            $.ajax({
                url: 'deletedata.php',
                type: 'GET',
                data: {id: id},
                error: function() {
                  alert('Something is wrong, couldn\'t delete record');
                },
                success: function(data) {
                    $("#" + id).remove();
                    alert("Record delete successfully.");  
                    location.reload();
                }
            });
        }
    });

     ////check box chacked property

          $(document).on('click','#select_all',function(e){
            if ($('#select_all').prop('checked',true)) 
            {
                $('.td_checkbox').prop('checked',true);
            }
            else
            {
                $('.td_checkbox').attr('checked',false);
            }

          	});


    });//ready function end

	 function func()
	 {
	  var countrydata=$('#search_input_country').val();
	 	$.ajax({
			  type: "POST",
			  url: "statedata.php",
			  data: {country:countrydata},
			  dataType: "text",
			  success: function (response) { 
	                    $('#state').html(response);
	                }
			  });	//ajax	
       }

     function func()
	 {
	  var countrydata=$('#search_input_country').val();
	 	$.ajax({
			  type: "POST",
			  url: "delete.php",
			  data: {country:countrydata},
			  dataType: "text",
			  success: function (response) { 
	                    $('#state').html(response);
	                }
			  });	//ajax	
       }






</script>
</body>
</html>