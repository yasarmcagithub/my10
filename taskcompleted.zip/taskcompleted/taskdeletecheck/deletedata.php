<?php
require_once('conn.php');
$id= $_GET['id'];
$sql="DELETE FROM personal_detail WHERE id='$id'";
$conn->query($sql);
// if($conn->query($sql))
// {
// 	echo "deleted sucssfully";
// }
// else
// {
// 	echo "Unable to Delete Please Check Sql query";
// }


?>