<?php
require_once('conn.php');

// echo $_GET['searchdata'];

$countryvalue= isset($_GET['countrydata']) ? $_GET['countrydata'] : "";
// echo $countryvalue;
$statevalue=isset($_GET['statedata']) ? $_GET['statedata'] : "" ;

$condition=isset($_GET['searchdata']) ? $_GET['searchdata'] : "" ;

// echo $condition;

$limit = 5;  
$sql = "SELECT * from personal_detail inner join country ON personal_detail.country=country.C_id INNER join state on personal_detail.state=state.s_id"; 
// echo $sql; 

if (isset($_GET['searchdata'])) 
{
	$sql.= " WHERE (first_name LIKE '%$condition%' || last_name LIKE '%$condition%' || email LIKE '%$condition%'|| gender LIKE '%$condition%'|| mobile_no LIKE '%$condition%'|| addr1 LIKE '%$condition%'|| addr2 LIKE '%$condition%'|| country_name LIKE '%$condition%'|| state_name LIKE '%$condition%'|| city LIKE '%$condition%'|| pincode LIKE '%$condition%')";
}	
if (isset($_GET['countrydata'])) 
{
	$sql.= " AND country='".$countryvalue."'";

}
if (isset($_GET['statedata'])) 
{
	$sql.= " AND state='".$statevalue."'";

}


$rs_result = mysqli_query($conn, $sql);  

$row = mysqli_num_rows($rs_result); 
// echo $row;
$total_records = $row;  
$total_pages = ceil($total_records / $limit); 
// echo $total_pages;
$limit = 5;  
if (isset($_GET["page"])) { $page  = $_GET["page"]; } else { $page=1; };
// echo $page;  
$start_from = ($page-1) * $limit;  

  
$sql = "SELECT * FROM personal_detail inner join country ON personal_detail.country=country.C_id INNER join state on personal_detail.state=state.s_id";  
if (isset($_GET['searchdata'])) 
{
	$sql.= " WHERE (first_name LIKE '%$condition%' || last_name LIKE '%$condition%' || email LIKE '%$condition%'|| gender LIKE '%$condition%'|| mobile_no LIKE '%$condition%'|| addr1 LIKE '%$condition%'|| addr2 LIKE '%$condition%'|| country_name LIKE '%$condition%'|| state_name LIKE '%$condition%'|| city LIKE '%$condition%'|| pincode LIKE '%$condition%')";
	// echo $sql;

}
if (isset($_GET['countrydata'])) 
{
	$sql.= " AND country='".$countryvalue."'";

}
if (isset($_GET['statedata'])) 
{
	$sql.= " AND state='".$statevalue."'";

}


	

$sql.= " LIMIT $start_from, $limit";
// echo $sql;

$rs_result = mysqli_query($conn, $sql);   ///runquery

/////

 echo '<table id="list">
	    <thead>
            <tr>
				<th><input type="checkbox" id="select_all"></th>
				<th>First Name</th>
				<th>Last Name</th>
				<th>Email</th>
				<th>Gender</th>
				<th>Mobile Number</th>
				<th>Adress 1</th>
				<th>Adress 2</th>
				<th>Country</th>
				<th>State</th>
				<th>City</th>
				<th>Pincode</th>
				<th>Edit</th>
				<th>Delete</th>
			</tr>
		</thead>
       <tbody id="tabledata">';
        foreach($rs_result as $row) {
        echo' 	
		     <tr id="'.$row["id"].'">
		    	<td><input type="checkbox" class="td_checkbox"  value="'.$row["id"].'" ></td>
			    <td>'.$row["first_name"].'</td>
		   		<td>'.$row["last_name"].'</td>
		   		<td>'.$row["email"].'</td>  	
		   		<td>'.$row["gender"].'</td>
		   		<td>'.$row["mobile_no"].'</td>
		   		<td>'.$row["addr1"].'</td> 
		   		<td>'.$row["addr2"].'</td>
		   		<td>'.$row["country_name"].'</td>
		   		<td>'.$row["state_name"].'</td> 
		   		<td>'.$row["city"].'</td>
		   		<td>'.$row["pincode"].'</td>
		   		<td><a href=" personal_detail.php?id='.$row['id'].' "><img src="edit.png" height="20px" width="20px"></a></td>
		   		<td><a id="'.$row['id'].'" class="delete_btn" _href=" deletedata.php?id='.$row['id'].' "><img src="delete.png" height="20px" width="20px"></td>
		    </tr> ';}
echo' </tbody> </table>'; ?>



	 <div align="center">
<ul class='pagination text-center' id="pagination">
<?php if(!empty($total_pages)):for($i=1; $i<=$total_pages; $i++):  
			if($page == $i):?>
            <li class='active'  id="<?php echo $i;?>"><a href='pagination.php?page=<?php echo $i;?>'><?php echo $i;?></a></li> 
			<?php else:?>
			<li id="<?php echo $i;?>"><a href='pagination.php?page=<?php echo $i;?>'><?php echo $i;?></a></li>
		<?php endif;?>			
<?php endfor;endif;?>  
</div>
</div>








